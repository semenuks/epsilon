<?php
// the $_POST[] array will contain the passed in filename and data
// the directory "data" is writable by the server (chmod 777)
$filename = "data/".$_POST['filename'];
$data = $_POST['filedata'];
// write the file to disk
file_put_contents($filename, $data);
	$destination = "data/".$_POST["filename"];
	$prefix = $_POST["metadata"];
	$file_handle = fopen($destination, "r");
	$langs_array = array();
	$i = 0;
	while (!feof($file_handle)) {
		$line_of_text = fgetcsv($file_handle);
		if ($i === 0) {array_push($langs_array, "design version,chain number,generation number,learner type,participant age,participant sex,test3 answer".implode(",", $line_of_text));}
		else {array_push($langs_array, $prefix."".$_POST['test'].",".implode(",", $line_of_text));};
		$i++;
	}
	fclose($file_handle);

	$file_handle = fopen($destination, "w");
	$i = 0;
	foreach ($langs_array as $value) {
		if ($i !== (count($langs_array)-1)) {
			fwrite($file_handle,$value);
			fwrite($file_handle,"\r\n");
		}
		$i++;
	}
	fclose($file_handle);
?>
