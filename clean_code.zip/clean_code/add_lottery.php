<?php
	file_put_contents('data/lottery.csv', $_POST["tickets"], FILE_APPEND);
?>
