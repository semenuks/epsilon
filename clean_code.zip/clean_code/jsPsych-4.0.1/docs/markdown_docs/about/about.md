# About jsPsych

jsPsych was created by [Josh de Leeuw](http://pages.iu.edu/~jodeleeu) at Indiana University.

### Citation

de Leeuw, J. R. (2014). jsPsych: A JavaScript library for creating behavioral experiments in a web browser. _Behavior Research Methods_, Advance online publication. doi:10.3758/s13428-014-0458-y.

---

Documentation generated with [mkdocs](http://www.mkdocs.org) 

