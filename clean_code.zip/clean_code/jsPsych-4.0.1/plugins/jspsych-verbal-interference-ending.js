/* jspsych-text.js
 * Josh de Leeuw
 *
 * This plugin displays text (including HTML formatted strings) during the experiment.
 * Use it to show instructions, provide performance feedback, etc...
 *
 * documentation: https://github.com/jodeleeuw/jsPsych/wiki/jspsych-text
 *
 *
 */

/*
    what i need to figure out:
      - why can't i place the letters in the middle of the screen in terms of vertical alignmnet?
      - (in general) how to work with displaying the stimlu when you need them;
      - (in general) how does the keyboard listener thing work?
      - console says that there's an uncaught typeerror - hwat does that mean?
      - where to delete the timers? (do i even need to?)

*/


(function($) {
    jsPsych['verbal-interference-ending'] = (function() {

        var plugin = {};

        plugin.create = function(params) {

            params = jsPsych.pluginAPI.enforceArray(params, ['verbal-interference-ending']);

            var trials = {}
            trials.stim = params.stim;
            var trials = [trials];
            return trials;
        };

        plugin.trial = function(display_element, trial) {

            // if any trial variables are functions
            // this evaluates the function and replaces
            // it with the output of the function
            trial = jsPsych.pluginAPI.normalizeTrialVariables(trial);

            // choosing random letters, how many we need
            var stim = trial.stim;
            var entered = '';

            // formatting for the plugin letter presentation

            function add_formatting(a) {
              var c = a;
              c = '<div><center><font size="15">'+c+'</font></center></div>';
              return c;
            };

            // displaying the letters
            display_element.html(add_formatting('_'+entered+'_'));

            var end_trial = function() {
              display_element.html(' ');
              // part where the collected data is analyzed
              var correct = false;
              if (entered.split('').sort().join('') === stim.split('').sort().join('')) {correct = true} else {correct = false};
              save_data(correct)
              t2 = setTimeout(function() { jsPsych.finishTrial(); }, 1000);
            };

            var after_response = function(info) {
              if (info.key == 13) {
                jsPsych.pluginAPI.cancelKeyboardResponse(keyboardListener);
                end_trial();
              } else if (info.key === 8 && entered !== '') {
                entered = entered.substring(0, entered.length - 1);
                display_element.html(add_formatting('_'+entered+'_'));
              } else if (info.key < 91 && info.key > 64) {
                entered = entered+String.fromCharCode(info.key).toUpperCase();
                display_element.html(add_formatting('_'+entered+'_'));
              };
            };


            // !!! just adding this makes the plugin stop being displayed after a key has been hit. need to figure out why
            // !!! in terms of what this function connects to
            var keyboardListener = jsPsych.pluginAPI.getKeyboardResponse(after_response, [], 'date', true);

            function save_data(correct) {
                jsPsych.data.write($.extend({}, {
                    "stimulus": stim,
                    "entered": entered,
                    "correct": correct
                }, trial.data));
            }
        };

        return plugin;
    })();
})(jQuery);
