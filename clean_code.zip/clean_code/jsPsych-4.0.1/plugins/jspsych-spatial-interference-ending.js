/* jspsych-text.js
 * Josh de Leeuw
 *
 * This plugin displays text (including HTML formatted strings) during the experiment.
 * Use it to show instructions, provide performance feedback, etc...
 *
 * documentation: https://github.com/jodeleeuw/jsPsych/wiki/jspsych-text
 *
 *
 */

(function($) {
    jsPsych['spatial-interference-ending'] = (function() {

        // do i need to kill timers?

        var plugin = {};

        plugin.create = function(params) {

            params = jsPsych.pluginAPI.enforceArray(params, ['spatial-interference-ending']);

            // need to write down what each thing means

            var trials = {}
            trials.stim = params.stim;
            trials.ladder = params.ladder || [2,1];
            trials.same_order = params.same_order || true;
            trials.dimentions = params.dimentions || [4,4]; // number of columns, then number of rows
            trials.col = params.col || 100; // column width
            trials.row = params.row || 100; // row height
            trials.response_key = params.response_key || 13;
            trials.timing_after = params.timing_after || 500;
            var trials = [trials];
            return trials;
        };

        plugin.trial = function(display_element, trial) {

            // if any trial variables are functions
            // this evaluates the function and replaces
            // it with the output of the function
            trial = jsPsych.pluginAPI.normalizeTrialVariables(trial);

            // assigning things to local variables

            var stim = trial.stim;
            var same_order = trial.same_order;
            var dimentions = trial.dimentions;
            var col = trial.col;
            var row = trial.row;
            var response_key = trial.response_key;
            var timing_after = trial.timing_after;
            var up_ladder = trial.ladder[0];
            var down_ladder = trial.ladder[1];
            var clicked_blocks = [];
            var next_level = 1;


            // create the table

            function create_table() {
              var x = '<center><table border="1">';
              for (var i=0; i<dimentions[0]; i++) {
                x = x+'<col width="'+col+'"><tr>';
                for (var j=0; j<dimentions[1]; j++) {
                  x = x+'<td height="'+row+'"; class="'+(i*dimentions[0]+j)+'"></td>';
                }
                x = x+'</tr>';
              }
              x = x+'</table></center>';
              return x;
            };

            display_element.html(create_table());

            // what to dow when the thing is clicked

            $("td").click(function() {
              var new_clicked = parseInt(this.classList[0]);
              if (clicked_blocks.indexOf(new_clicked) !== -1) {
                clicked_blocks.splice(clicked_blocks.indexOf(new_clicked),1);
              } else {
                clicked_blocks.push(new_clicked);
              }
              $(this).toggleClass("jspsych-spatial-interference-blue");
            });

            function same_or_no() {
              if (JSON.stringify(clicked_blocks.sort()) === JSON.stringify(stim.sort())) { return true;} else {return false;} ;
            };

            var end_trial = function() {
              jsPsych.pluginAPI.cancelKeyboardResponse(keyboardListener);
              display_element.html('');
              save_data('');
              t2 = setTimeout(function() { jsPsych.finishTrial(); }, timing_after);//!! do i need to specify this?
            };

            var after_response = function() {};

            var keyboardListener = jsPsych.pluginAPI.getKeyboardResponse(end_trial, [response_key], 'date', true);

            function save_data(stimulus) {
                jsPsych.data.write($.extend({}, {
                    "stim": stim,
                    "clicked_blocks": clicked_blocks,
                    "previous_stim": stim,
                    "same": same_or_no(),
                    //"level": level
                }, trial.data));
            }
        };

        return plugin;
    })();
})(jQuery);
