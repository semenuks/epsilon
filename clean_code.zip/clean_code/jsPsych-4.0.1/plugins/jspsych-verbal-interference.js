/* jspsych-text.js
 * Josh de Leeuw
 *
 * This plugin displays text (including HTML formatted strings) during the experiment.
 * Use it to show instructions, provide performance feedback, etc...
 *
 * documentation: https://github.com/jodeleeuw/jsPsych/wiki/jspsych-text
 *
 *
 */

/*
    what i need to figure out:
      - why can't i place the letters in the middle of the screen in terms of vertical alignmnet?
      - (in general) how to work with displaying the stimlu when you need them;
      - (in general) how does the keyboard listener thing work?
      - console says that there's an uncaught typeerror - hwat does that mean?
      - where to delete the timers? (do i even need to?)

*/


(function($) {
    jsPsych['verbal-interference'] = (function() {

        var plugin = {};

        plugin.create = function(params) {

            params = jsPsych.pluginAPI.enforceArray(params, ['verbal-interference']);

            var trials = {}
            trials.level = params.level;
            trials.timing = params.timing;
            trials.timing_after = params.timing_after || 500;
            var trials = [trials];
            return trials;
        };

        plugin.trial = function(display_element, trial) {

            // if any trial variables are functions
            // this evaluates the function and replaces
            // it with the output of the function
            trial = jsPsych.pluginAPI.normalizeTrialVariables(trial);


            // the array of all of the possible letter you can use
            var letters = ['B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z'];

            // choosing random letters, how many we need
            var level = trial.level;
            var timing = trial.timing;
            var timing_after = trial.timing_after;
            var chosen_letters = [];
            var chosen_letters_string = '';
            var leftovers = letters;

            // formatting for the plugin letter presentation

            function add_formatting(a) {
              var b = a;
              var c = '';
              function artostr(x) {
                c = c+x;
              };
              b.forEach(artostr);
              chosen_letters_string = c;
              c = '<div><center><font size="15">'+c+'</font></center></div>';
              return c;
            };

            for (var i=0; i<level; i++) {
              var x = Math.round(Math.random()*letters.length-1);
              var new_letter = leftovers.splice(x,1);
              chosen_letters.push(new_letter);
            };

            var chosen_letters_string = '';

            // setting the timer
            t1 = setTimeout(function() {end_trial();}, trial.timing);

            // displaying the letters
            display_element.html(add_formatting(chosen_letters));

            var end_trial = function() {
              display_element.html(' ');
              save_data(chosen_letters_string);
              t2 = setTimeout(function() { jsPsych.finishTrial(); }, timing_after);
            };

            var after_response = function() {};


            // !!! just adding this makes the plugin stop being displayed after a key has been hit. need to figure out why
            // !!! in terms of what this function connects to
            var keyboardListener = jsPsych.pluginAPI.getKeyboardResponse(after_response, []);

            function save_data(stimulus) {
                jsPsych.data.write($.extend({}, {
                    "stimulus": stimulus,
                    "level": level
                }, trial.data));
            }
        };

        return plugin;
    })();
})(jQuery);
