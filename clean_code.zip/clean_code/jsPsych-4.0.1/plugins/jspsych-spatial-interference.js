/* jspsych-spatial-interference.js
 * Arturs Semenuks
 *
 * This plugin displays text (including HTML formatted strings) during the experiment.
 * Use it to show instructions, provide performance feedback, etc...
 *
 * documentation: https://github.com/jodeleeuw/jsPsych/wiki/jspsych-text
 *
 *
 */

(function($) {
    jsPsych['spatial-interference'] = (function() {

        var plugin = {};

        plugin.create = function(params) {

            params = jsPsych.pluginAPI.enforceArray(params, ['spatial-interference']);

            // need to write down what each thing means

            var trials = {}
            trials.level = params.level;  // level of the task = how many blocks are shown there
            trials.timing = params.timing || 1000; // for how long each block is shown
            trials.timing_after = params.timing_after || 500; // the length of the pause following the showing of each block
            trials.simultaneously = params.simultaneously || false; // should all the blocks be shown simultaneously or one by one?
            // not yet implememnted
            trials.same_order = params.same_order || false; // should the blocks then be pressed in the same order or no?
            // not yet implemented
            trials.dimentions = params.dimentions || [4,4]; // number of rows, then number of columns
            // doesn't yet properly work
            trials.col = params.col || 100; // column width
            trials.row = params.row || 100; // row height
            var trials = [trials];
            return trials;
        };

        plugin.trial = function(display_element, trial) {

            // if any trial variables are functions
            // this evaluates the function and replaces
            // it with the output of the function
            trial = jsPsych.pluginAPI.normalizeTrialVariables(trial);

            // assigning things to local variables
            var level = trial.level;
            var timing = trial.timing;
            var timing_after = trial.timing_after;
            var simultaneously = trial.simultaneously;
            var same_order = trial.same_order;
            var dimentions = trial.dimentions;
            var col = trial.col;
            var row = trial.row;

            // timeouthandlers
            var TimeoutHandlers = [];

            // function for randomly choosing the blocks that will be activated
            var chosen_blocks = [];

            function choose_which_blocks() {
              var x = dimentions[0]*dimentions[1];
              x = Array.apply(null, {length: x}).map(Number.call, Number);
              for (i = 0; i < level; i++) {
                var rand = Math.round(Math.random()*x.length-1);
                var new_block = x.splice(rand,1);
                chosen_blocks.push(new_block[0]);
              };
            };
            choose_which_blocks();

            // function for creating a table the right size


            function create_table(r) {
              var x = '<center><table border="1">';
              for (var i=0; i<dimentions[0]; i++) {
                x = x+'<col width="'+col+'"><tr>';
                for (var j=0; j<dimentions[1]; j++) {
                  x = x+'<td height="'+row+'"';
                  if ((i*dimentions[0]+j) === r) {
                    x = x+'; class="jspsych-spatial-interference-blue">';
                  };
                  x = x+'</td>';
                }
                x = x+'</tr>';
              }
              x = x+'</table></center>';
              return x;
            };

            // displaying the blocks
            function display_blocks(i) {
              display_element.html(create_table(chosen_blocks[i]));
              if (i === (level-1)) {
                var timer = setTimeout(function() {end_trial();}, timing);
                TimeoutHandlers.push(timer);
              } else {
                var timer = setTimeout(function() {display_empty(i);}, timing);
                TimeoutHandlers.push(timer);
              }
            }

            function display_empty(i) {
              display_element.html(create_table(-1));
              var timer = setTimeout(function() {display_blocks(i+1);}, timing_after);
              TimeoutHandlers.push(timer);
            };


            display_blocks(0);


            var end_trial = function() {
              for (i=0; i<TimeoutHandlers.length; i++) {
                clearTimeout(TimeoutHandlers[i]);
              };
              display_element.html(create_table(-1));
              save_data(chosen_blocks);
              t2 = setTimeout(function() { jsPsych.finishTrial(); }, timing_after);
            };

            var after_response = function() {};


            function save_data(stimulus) {
                jsPsych.data.write($.extend({}, {
                    "stimulus": chosen_blocks,
                    "level": level
                }, trial.data));
            }
        };

        return plugin;
    })();
})(jQuery);
