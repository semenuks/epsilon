<!doctype html>
<html>
    <head>
      <meta charset="UTF-8">
        <title>Спасибо за участие!</title>
        <script src='jquery-1.11.2.min.js'></script>
        <link href='jsPsych-4.0.1/css/jspsych-additional.css' rel='stylesheet' type='text/css'></link>
        <style>
        	body {
        		margin-top: 10%;
        		margin-right: 25%;
        		margin-left: 25%;
        	}
        </style>
    </head>
    <body>
      <left>
      <div>
          <p>
            Большое спасибо за участие! <b>Чтобы иметь возможность выиграть приз, запишите все коды, данные ниже, целиком. Эта страница закроется через 3 минуты</b>. В конце апреля или начале мая часть случайно выбранного кода-победителя будет опубликована на этом сайте. Для получения приза обладателю этого кода нужно будет в течение 30 дней с момента публикации связаться с нами по адресу aleksandrs.berdicevskis@uit.no, указав недостающую часть кода. Кроме того, любой участник сможет узнать, чему был посвящен эксперимент.
          </p>
      </div>
      <div class="attach_to"></div>
      </left>

    </body>
    <script type="text/javascript">
    	/////
    	// changing the window url
    	/////
    	window.history.replaceState( {} , 'Общение с эпсилонцами', '/delta/index.php' );

    	/// getting the number of letery tickets that need to be generated
    	var tickets_number= <?php
    		echo $_GET["d"];
    	?>

    	// function for generating a lottery ticket
    	function lottery() {
    		var answer = [];
    		for (var i = 0; i<14; i++) {
    			var r = Math.floor(Math.random()*20)+68;
    			answer.push(String.fromCharCode(r));
    		}
    		return answer.join("");
    	}

    	// generating all the lottery tickets
    	var tickets = [];
    	var display_tickets = '<p>';
    	var pass_to_php = '';
    	for (var i=0; i<tickets_number; i++) {
    		tickets.push(lottery());
    		display_tickets += tickets[i]+'</p><p>';
    		pass_to_php += tickets[i]+'\r\n';
    	};
    	display_tickets += '</p>';

    	// displaying all the lottery tickets
    	$(".attach_to").append(display_tickets);

    	// writing down the tickets into a file
    	$.ajax({
    		type: 'post',
    		cache: false,
    		url: 'add_lottery.php',
    		data: {tickets: pass_to_php}
    	});

	t1 = setInterval(function() {window.location.replace("end.html"); clearInterval(t1);}, 180000);

    </script>
</html>
