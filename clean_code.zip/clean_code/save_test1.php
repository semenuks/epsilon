<?php
	file_put_contents('data/test1.csv', $_POST["data"]."\r\n", FILE_APPEND);
?>
