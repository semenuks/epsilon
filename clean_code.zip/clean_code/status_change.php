<?php
	$file_handle = fopen("langs/langs.csv", "r");
	$langs_array = array();
	while (!feof($file_handle)) {
		$line_of_text = fgetcsv($file_handle);
		array_push($langs_array, implode(",", $line_of_text));
	}
	fclose($file_handle);
	
	$changed_line = explode(",",$langs_array[$_GET["line"]]);
	$changed_line[17] = $_GET["change"];
	$langs_array[$_GET["line"]] = implode(",",$changed_line);

	$file_handle = fopen("langs/langs.csv", "w");
	$i = 0;
	foreach ($langs_array as $value) {
		fwrite($file_handle,$value);
		if ($i !== (count($langs_array)-1)) {fwrite($file_handle,"\r\n");}
		$i++;
	}
	fclose($file_handle);
?>
