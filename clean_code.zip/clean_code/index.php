<!doctype html>
<html>
    <head>
      <meta charset="UTF-8">
        <title>Добро пожаловать!</title>
        <script src='jquery-1.11.2.min.js'></script>
        <script src='idle-timer.min.js'></script>
        <link href='jsPsych-4.0.1/css/jspsych-additional.css' rel='stylesheet' type='text/css'></link>
    </head>
    <body>
      <center>
     <div style="display: inline-block; position: fixed; top: 0; bottom: 0; left: 0; right: 0; height: 200px; width: 900px; margin: auto;">
          <p>
            Примите участие в увлекательном лингвистическом эксперименте, освойте язык аборигенов планеты Эпсилон и получите шанс выиграть подарочный купон на 70 евро в книжный интернет-магазин!
          </p>
          <button id='participateButton'>Условия участия</button>
          <div id='sorryText' style='display:none;'></div>
      </div>
      <div><p></p></div>
      </center>

    </body>
    <script type="text/javascript">


    	// gettin the browser information
    	var browser = <?php
	if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE){
		$browser = 'Microsoft Internet Explorer';
	}elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE) {
		$browser = 'Google Chrome';
	}elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE) {
		$browser = 'Mozilla Firefox';
	}elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE) {
		$browser = 'Opera';
	}elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE) {
		$browser = 'Apple Safari';
	}else {
		$browser = 'error'; //<-- Browser not found.
	}

	echo json_encode($browser);
	?>;


	window.history.replaceState( {} , 'Добро пожаловать!', '/delta/index.php' );
    	////////////
    	// variables specified in the design
    	var maxChainLength = 10;
    	////////////


      // only letting mozilla and firefox work

    	if ((browser !== 'Google Chrome') && (browser !== 'Mozilla Firefox')) {
    		$('#participateButton').on('click',function(){
    			$('#sorryText').html('<p>Спасибо за интерес. К сожалению, на данный момент эксперимент можно пройти только в Mozilla Firefox или Google Chrome. Мы будет благодарны, если вы сможете зайти на сайт в одном из этих браузеров.</p>').show();
    		});
    	} else {
    	$('#participateButton').on('click',function(){

	        var slots = 0;
	        $.ajax({
	        	type: 'post',
	        	cache: false,
	        	url: 'get_line.php',
	        	async: false
	        })
	        	.done(function(data) {
	        	});


	        // reformatting the slots array and getting the availability of the lines
	        for (i=0;i<slots.length;i++) {
	        	slots[i] = [i+1,slots[i][0],parseInt(slots[i][1])];
	        };
	        var slots2 = slots;

	        // choosing a random line
	        choose_line = function() {
		        var i=45; // the number of lines you could choose among
		        var haveAFreeLine = false;
		        var all_maxChainLength = true;
		        var y = 'l1';
		        var rand_n = 0;
		        while (i !== 0) {
			        rand_n = Math.floor(Math.random()*i);
			        if ( (isNaN(slots2[rand_n][2])) || (slots2[rand_n][2] >= maxChainLength) ) {
				        if (!(slots2[rand_n][2] >= maxChainLength)) {all_maxChainLength = false};
				        slots2.splice(rand_n,1);
				        i--;
			        } else {
				        i = 0;
				        haveAFreeLine = true;
			        };
		        };
		        if (haveAFreeLine) {return slots2[rand_n];}
		        else if (all_maxChainLength) {return [-1,0,0]}
		        else {return [46,0,0]}
	        };
	        var x = choose_line();

		// changing the availability of the line
		if ((!(x[0] === -1)) && (!(x[0] === 46))) {
			$.ajax({
				type: 'get',
				async: false,
				url: "status_change.php?line="+x[0]+"&change=c"+x[2]
			});
		};

    		shouldReturn = false;
	        // message the participants of the outcome
	        if (x[0] === -1) {
	        	$('#sorryText').html('<p>Данный этап эксперимента закончен, но скоро начнется следующий. Загляните к нам через несколько часов. Спасибо!</p>').show();
	        } else if (x[0] === 46) {
	        	$('#sorryText').html('<p>К сожалению, на данный момент в системе нет свободных мест. Попробуйте перезагрузить страницу через несколько минут. Спасибо за терпение!</p>').show();
	        } else {
	        	$('#sorryText').html('<p>Спасибо за интерес. Сейчас вы будете перенаправлены на начальную страницу.</p>').show();
			// redirecting
			window.location.replace("experiment.php?line="+x[0]+"&type="+x[1]+"&prev="+x[2]);
			$(document).idleTimer('destroy');
	        };

	});
	}
    </script>
</html>
