<?php
        $file_handle = fopen("langs/langs.csv", "r");
        $langs_array = array();
        $i = 0;
        while (!feof($file_handle) ) {
	        $line_of_text = fgetcsv($file_handle);
	        if ($i != 0) {array_push($langs_array, array($line_of_text[16],$line_of_text[17]));}
	        $i++;
        }
        fclose($file_handle);
        echo json_encode($langs_array);
?>
