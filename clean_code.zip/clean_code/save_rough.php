<?php
	file_put_contents('data/rough_data.csv', $_POST["data"]."\r\n", FILE_APPEND);
?>
