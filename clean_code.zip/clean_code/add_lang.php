<?php
	$filename = "langs/lang_".$_POST['chain'].".csv";
	$data = "\r\n".$_POST['new_language'];
	file_put_contents($filename, $data, FILE_APPEND);
?>
