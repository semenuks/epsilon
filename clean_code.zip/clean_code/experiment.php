<!doctype html>
<html>
    <head>
        <title>Общение с эпсилонцами</title>
        <meta charset="UTF-8">
        <script src='jquery-1.11.2.min.js'></script>
        <script src='idle-timer.min.js'></script>
        <script src='jsPsych-4.0.1/jspsych.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-text.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-single-stim.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-single-stim2.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-call-function.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-verbal-interference.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-verbal-interference-ending.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-spatial-interference.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-spatial-interference-ending.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-survey-texta.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-survey-text4.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-survey-textd.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-survey-text.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-survey-likert.js'></script>
        <script src='jsPsych-4.0.1/plugins/jspsych-html.js'></script>
        <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
        <link href="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/black-tie/jquery-ui.min.css" rel="stylesheet" type="text/css"></link>
        <style>
        	body {
        		margin-top: 10%;
        	}
        	html {
			font-family: 'Open Sans', 'Arial', sans-serif;
			font-size: 18px;
			line-height: 1.6em;
		}

		#x {
			margin-right: 25%;
			margin-left: 25%;
		}

		.test {
			background-color: blue;
		}

		.x {
			margin-right: 25%;
			margin-left: 25%;
		}

        	input[type="text"] {
		    font-family: 'Open Sans', 'Arial', sans-sefif;
		    font-size: 14px;
		}

		button {
		    padding: 0.5em;
		    background-color: #eaeaea;
		    border: 1px solid #eaeaea;
		    color: #333;
		    font-family: 'Open Sans', 'Arial', sans-serif;
		    font-size: 14px;
		    cursor: pointer;
		}

		button:hover {
		    border:1px solid #ccc;
		}

		#jspsych-progressbar-container {
			color: #777;
			border-bottom: 2px solid #dedede;
			background-color: #f3f3f3;
			margin-bottom: 1em;
			text-align: center;
			padding: 10px 0px;
		}

		#jspsych-progressbar-container s {

		}

		#jspsych-progressbar-outer {
			background-color: #dedede;
			border-radius: 5px;
			padding: 1px;
			width: 800px;
			margin: auto;
		}

		#jspsych-progressbar-inner {
			background-color: #aaa;
			width: 0%;
			height: 1em;
			border-radius: 5px;
		}

        </style>
    </head>
    <body>
    </body>

    <script type="text/javascript">

    function drawProgressBar() {
			$('body').prepend($('<div id="jspsych-progressbar-container"><span>Completion Progress</span><div id="jspsych-progressbar-outer"><div id="jspsych-progressbar-inner"></div></div></div>'));
		}

    	/////
    	// changing the window url
    	/////
    	window.history.replaceState( {} , 'Общение с эпсилонцами', '/delta/index.php' );

    	/////
    	// setting what happens when a user isn't active for a long time in different phases of the experiment
    	/////

    	// the timer for the first part of the experiment

    	$(document).idleTimer(600000);
    	$(document).bind("idle.idleTimer", function(){
    		  $(document.documentElement).idleTimer('destroy');
		      notInactiveForTooLong = true;
	        $(document).idleTimer('destroy');
	        if (shouldRedirect) {window.location.replace("time_out.html");};
	    });

	/////////////////
	/* what happens when the window is closed prematurely */
	/////////////////

	window.onbeforeunload = preClosingCode;
	function preClosingCode(){
		if ((notclosedBeforeEnd) || (notInactiveForTooLong)) {return null} else {return 'Вы действительно хотите покинуть страницу? Все ваши данные будут потеряны.'};
	};

	$(window).unload(function () {
		if (! notclosedBeforeEnd) {
	        $.ajax({
		        type: 'get',
		        async: false,
		        url: "status_change.php?line="+lang_line+"&change="+(lang_prev)
	        });
		};
	});


	////////////
  // variables specified in the design
  ///////////
  var bottleneck = 7;
  var numberTrainingSessionsL1 = 6;
	var numberTrainingSessionsL2 = 3;
	var numberTrainingSessionsCurrent = numberTrainingSessionsL1;
	var interimTestL1 = 8;
	var interimTestL2 = 8;
	var interimTestCurrent = interimTestL1;
	var demoTimeL1 = 4000;
	var demoTimeL2 = 4000;
	var demoTimeCurrent = demoTimeL1;
	var numberPicsToMatch = 6; // the number of (alternative) pictures shown in each trial in the first testing session
	var numberWordsInPerfTest = 16; //the number of words in first test


	///////////
	// other important variables
	///////////
	var notclosedBeforeEnd = false; // whether the participant closed the window before finishing the experiment
	var notInactiveForTooLong = false; // variable making the warning message not appear if true
	var toIdleOrNotToIdle = false; // a variable telling whether two secondary idletimers should work or no.
	var toWriteOrNotToWrite = true; // a variable telling whether to write the things in the languages
	var lang_line = <?php echo $_GET["line"] ?>; // which language to use
	var shouldRedirect = true;
	var lang_type = <?php echo json_encode($_GET["type"]) ?>; // what type of presentation - l1 or l2
	var lang_prev = <?php echo $_GET["prev"] ?>; // what is the number of previous generations passed to the url
	var design_version = 1;

	var meta_variables = [design_version, lang_line, lang_prev, lang_type];

	// making the window unavailable


    /* introductory part */
    // first introductory screen
    var intro1 = {
      type: 'text',
      text: '<div id="x"><p>ПОЖАЛУЙСТА, ВНИМАТЕЛЬНО ПРОЧТИТЕ ТЕКСТ НИЖЕ</p><p>Эксперимент посвящен проверке некоторых современных лингвистических гипотез. Он займет <b>10-20 минут</b>, в течение которых вы попробуете выучить неизвестный вам язык планеты Эпсилон. Если вам меньше 16 лет, или если русский язык для вас не является родным, или если вы лингвист, мы просим вас воздержаться от участия (все эти факторы могут повлиять на ваши результаты, а нам нужно знать, как себя ведет обыкновенный взрослый русскоязычный человек).</p><p>Руководитель исследовательской группы — Александр Бердичевский (Университет Тромсё — Норвежский арктический университет, адрес для связи — aleksandrs.berdicevskis@uit.no). Эксперимент проводится в соответствии с законодательством Королевства Норвегия. Участие добровольно, вы можете прекратить его в любой момент. Участие анонимно: мы не собираем и не храним имен, адресов электронной почты, IP-адресов и никаких других данных, которые позволили бы идентифицировать участников. Прочие данные (возраст, пол, результаты) будут бессрочно храниться у экспериментаторов и могут быть впоследствии использованы для исследований и опубликованы. Призовые коды (см. следующую страницу) хранятся отдельно от прочих данных и не могут быть с ними связаны, после выдачи призов все коды уничтожаются.</p><p><b>Технические требования</b></p><p>Никаких специальных средств (в т.ч. аудио) вам не понадобится. В браузере должен быть разрешен JavaScript (если вы не знаете, что это такое, то, скорее всего, он у вас разрешен. Можете проверить <a href="http://enable-javascript.com/ru/" target="blank">здесь</a>). На мобильных устройствах сайт может работать некорректно, кроме того, маленький экран будет неудобен, поэтому рекомендуем пользоваться ноутбуком или стационарным компьютером. При нестандартных способах подключения к интернету (VPN, USB-модем) сайт иногда не работает: к сожалению, мы не можем устранить эту проблему. При прочих технических затруднениях напишите Артуру Семенюку на asemenuk@ucsd.edu. </p><p><b><u>Нажмите пробел для продолжения</b></u></p></div>',
      cont_key: ' '
    };

    // second introductory screen
    var intro2 = {
      type: 'text',
      text: '<div id="x"><p><b>Правила эксперимента</b></p><p>Прежде чем начать, пожалуйста, убедитесь, что в течение ближайших 20 минут вы сможете заниматься только экспериментом, ни на что другое (разговоры, музыка, почта, чат) не отвлекаясь. <b>Ничего не записывайте</b> ни на бумажке, ни на компьютере (за исключением тех случаев, когда вас попросят ввести ответ на вопрос). Не участвуйте в эксперименте более одного раза.</p><p>Мы не можем проконтролировать, соблюдаете ли вы эти правила, но мы полагаемся на вашу честность. Нарушения могут привести к сильному искажению наших результатов. Если вы по какой-либо причине нарушили правила, напишите, пожалуйста, об этом нам на адрес aleksandrs.berdicevskis@uit.no.</p><p><b>Вознаграждение</b></p><p>Среди участников, дошедших до конца, будет разыгран приз. Победители получат право выбрать в интернет-магазине (Amazon, Ozon, "Лабиринт" или любой другой легально работающий магазин, в котором у нас будет техническая возможность совершить покупку) книжек на сумму до 70 евро (включая доставку), мы оплатим заказ.</p><p>По окончании эксперимента вы получите некоторое количество кодов. Каждый код — это один ваш лотерейный билет. Чем лучше вы справитесь с заданиями, тем больше кодов вы получите, чем больше кодов — тем выше вероятность выиграть! Обязательно сохраните все коды целиком. По окончании эксперимента будет случайно выбран код-победитель, часть которого мы опубликуем на этом сайте. Для получения приза нужно будет связаться с нами по указанному выше адресу и назвать недостающую часть кода.</p><p><b><u>Нажмите пробел для продолжения. </b></u></p><div>',
      cont_key: ' '
    };

    // all the variables needed for writing down participant info
    var participant_age = 0;
    var participant_sex = '';

    // function for checking that the participant filled everything out
    var check_consent = function() {
        if (($('#consent_checkbox').is(':checked')) & ($('#linguist_checkbox').is(':checked')) & ((document.getElementById('sex_m').checked || document.getElementById('sex_f').checked)) & (jQuery.trim(document.getElementById('age').value) !== ''))  {
            if (isNaN(document.getElementById('age').value)) { alert("Пожалуйста, введите ваш возраст цифрами."); }
            else if(parseInt(document.getElementById('age').value) < 16) {alert("Извините, в этом эксперименте исследуется поведение взрослых участников. Вам должно быть не менее 16 лет.");}
            else {
	            participant_age = parseInt(document.getElementById('age').value);
	            if (document.getElementById('sex_m').checked) {participant_sex = 'M'}
	            else {participant_sex = 'F'};
	            return true;
            };
        }
        else {
            alert("Для участия необходимо принять условия и указать запрашиваемые данные.");
            return false;
        }
        return false;
    };

    // consent form block
    var add_meta_variables = false;
    var consent_form = {
        type:'html',
        pages: [{url: "external_page2.html", cont_btn: "start", check_fn: check_consent}],
        on_finish: function() {
          if (add_meta_variables) {
          	meta_variables.push(participant_age);
          	meta_variables.push(participant_sex);
          } else {add_meta_variables = true};
        }
    };

    var intro3 = {
    	type: 'text',
    	text: '<div id="x"><p>ИНСТРУКЦИЯ</p><p>Вы участвуете в космической экспедиции, налаживающей контакт с обитателями далекой планеты Эпсилон. Эпсилонцы приветливы и охотно показывают свою планету. Сегодня эпсилонец по имени Сеуссе хочет научить вас своему языку. </p><p>Он будет показывать вам фотографии эпсилонских животных и описывать их по-эпсилонски. Ничего не нажимайте, просто смотрите. Время от времени Сеуссе будет проверять, как вы усваиваете язык. Обязательно отвечайте на все вопросы, даже если не уверены в ответе.</p><p>Не расстраивайтесь, если вам покажется, что у вас не очень получается: ваш друг будет изо всех сил стараться вас понять. Главное, чтобы он видел, что вы стараетесь. Не тратьте много времени на ответ. Если вы слишком задумаетесь, Сеуссе вас поторопит. Если это случится, то ответьте как можно скорее, иначе он обидится на ваше молчание. <b>Ничего не записывайте и не отвлекайтесь</b>. </p><p>Удачи!</p><p><b><u>Готовы начать? Нажмите пробел.</u></b></p></div>',
    	cont_key: ' ',
    };

    function add_center_formatting(x,a,b) {
    	var y = x;
    	y = '<div id="x" align="center">'+y+'</div>';
    	return y;
    };

    //////
    // the seusse reply part
    /////

    var practique_counter = 2;

    var return_replique = function(x) {
    	return {
		        type: 'single-stim',
		    	is_html: true,
		    	timing_response: 3000,
		    	continue_after_response: false,
		    	stimuli: [add_center_formatting('<p>Хорошо! Сеуссе считает, что ключ к успеху -- постоянная практика, и предлагает пройти тренировку '+x+'-й раз (из '+numberTrainingSessionsCurrent+').</p>',400,200)]
		};
    };


    var pre_pic = {
    	type: 'single-stim',
    	is_html: true,
    	timing_response: 3000,
    	continue_after_response: false,
    	stimuli: [add_center_formatting('<p>Приготовьтесь.</p>',400,200)],
    	on_finish: function() {
    		$(document).idleTimer("destroy");
    		shouldRedirect = false;
    	}
    };




    /////////////////
    /* language presentation part */
    /////////////////

    // get the language for the presentation

    var language = <?php
    	$fp = fopen("langs/lang_".$_GET["line"].".csv", "r");
    	$lang = array();
    	while (!feof($fp)) {
    	  $current = fgetcsv($fp);
    	  array_push($lang,$current);
    	}
    	fclose($fp);
    	echo json_encode($lang);
    ?>;


    // choosing which items not to use
    var not_using = [];
    var t = Array.apply(null, {length: 16}).map(Number.call, Number);
    for (var i=0;i<bottleneck;i++) {
    	not_using.push(t.splice(Math.floor(Math.random()*t.length),1)[0]);
    	setInterval(function(){var a = 0;},10); // otherwise the two random numbers are far too often next to each other
    };

    // connect the language to the pictures
    function combine_lang_and_pic(x) {
    	var y = x;
    	var answer = [];
	for (var i=0;i<y.length;i++) {
		answer.push([i,y[i],'<p>'+y[i]+'</p>','<img src=images/'+(i+1)+'.png>','images/'+(i+1)+'.png']);
		if (not_using.indexOf(i) === -1) {answer[i].push(true)} else {answer[i].push(false)};
	};
    	return answer;
    };
    var language2 = combine_lang_and_pic(language[language.length-1]);


    function remove_not_using(x) {
    	var y = x;
    	var answer = [];
    	for (var i=0;i<y.length;i++) {
    		if (y[i][5]) {answer.push(y[i])};
    	}
    	return answer;
    };
    var language3 = remove_not_using(language2);

    function only_not_using(x) {
    	var y = x;
    	var answer = [];
    	for (var i=0;i<y.length;i++) {
    		if (! y[i][5]) {answer.push(y[i])};
    	}
    	return answer;
    };
    var language4 = get_inner_array(only_not_using(language2),1).join('//');

    function get_inner_array(arr,n) {
    	var answer = [];
    	for (var i=0;i<arr.length;i++) {
    		answer.push(arr[i][n]);
    	};
    	return answer;
    };

    // blocks for presenting the language and interim tests
    // language presentation helper functions

    // when to change to l2 if it is needed
    var whenl2 = parseInt(lang_type.substring(1,5));
    var lern_type;
    if (((lang_type !== 'l0') && ((whenl2 === (lang_prev-1)) || (whenl2 === (lang_prev)) || (whenl2 === (lang_prev+1)))) || ((lang_type === 'l3') && (lang_prev !== 0))) {
    	numberTrainingSessionsCurrent = numberTrainingSessionsL2;
    	interimTestCurrent = interimTestL2;
    	demoTimeCurrent = demoTimeL2;
    	lern_type = 'l2';
    } else {lern_type = 'l1'};

    function make_learning_block_stimuli() {
    	var x = get_inner_array(language3,3);
       	var y = get_inner_array(language3,2);
       	var answer = [];
       	for (var i=0;i<x.length;i++) {
       		answer.push(add_center_formatting(''+x[i]+''+y[i]+'',400,200));
       	};
       	return answer;
    };


    // language presentation
    jsPsych.preloadImages(get_inner_array(language3,4), function(){})
    function return_learning_block() {
    return {
    	type: 'single-stim',
    	is_html: true,
    	timing_response: demoTimeCurrent,
    	continue_after_response: false,
    	stimuli: jsPsych.randomization.repeat(make_learning_block_stimuli(),1),
    	on_finish: function() {}
    };
    };

    var activate_timer = {
    	type: 'single-stim',
    	continue_after_response: false,
    	stimuli: '',
    	timing_response: 1,
    	on_finish: function() {
        toIdleOrNotToIdle = true;
    	}
    };

    // interim test helper functions
    function choose_interim_test_pictures() {
    	var answer = [];
    	var imgs = get_inner_array(language3,3);
    	for (var i=0;i<interimTestCurrent;i++) {
    		var x = Math.floor(Math.random()*imgs.length);
    		answer.push(imgs.splice(x,1));
    	};
    	return jsPsych.randomization.repeat(answer,1);
    };

    function make_interim_questions(x) {
    	var answer = [];
    	for (var i=0;i<x.length;i++) {
    		answer.push(['<div id="x" align="center">'+x[i]+'<p>Опишите эту картинку по-эпсилонски так, чтобы Сеуссе вас понял.</p></div>']);
    	};
    	return answer;
    };

    function return_interim_block() {
	    return {
	    	type: 'survey-texta',
	    	questions: make_interim_questions(choose_interim_test_pictures()),
	    	choices: [13],
	    	on_finish: function() {}
	    };
    };

    var deactivate_timer = {
    	type: 'single-stim',
    	continue_after_response: false,
    	stimuli: '',
    	timing_response: 1,
    	on_finish: function() {
    		toIdleOrNotToIdle = false;
    	}
    };

    // learning+interim chunk
    function make_li_stimuli() {
    		var answer = [];
    		answer.push(return_learning_block());
    		answer.push(activate_timer);
    		for (var i=0;i<(numberTrainingSessionsCurrent-1);i++) {
    			answer.push(return_interim_block());
    			answer.push(deactivate_timer);
    			answer.push(return_replique(i+2));
    			answer.push(return_learning_block());
    			answer.push(activate_timer);
     		};
    		return answer;
    };
    var chunk_timeline_1 = make_li_stimuli();

    var learning_interim_chunk = {
    	chunk_type: 'while',
    	timeline: chunk_timeline_1,
    	continue_function: function() {

    		return false;
    	}
    }

    ////////////////
    // the actual testing - part1
    ////////////////

    // creating one stimulus
    function make_test1_stimulus(num,stim) { //number is the index in the array
    	var langue = get_inner_array(language2,1);
    	var pics = get_inner_array(language2,3);
    	var nums = Array.apply(null, {length: pics.length}).map(Number.call, Number);

    	// choosing which way to choose other stimuli;
    	var which_way = Math.floor(Math.random()*10);
    	var rearranged = [0,2,3,4,1,5,6,7,8,10,11,12,9,13,14,15];
    	var rearranged_index = rearranged.indexOf(num);
    	var which_indexes = [];
    	if (which_way <3) {
    		var x = ~~(rearranged_index/8);
    		for (var i=0+x*8; i<8+x*8; i++) {
    			which_indexes.push(rearranged[i]);
    		};
    		which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    		which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    		if (which_indexes.indexOf(num) === -1) {
    			which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    			which_indexes.push(num);
    		};
    	} else {
    		var x = ~~(rearranged_index%4);
    		var y = Array.apply(null, {length: 4}).map(Number.call, Number); y.splice(x,1); y = y[Math.floor(Math.random()*3)];
    		for (var i=0; i<4; i++) {
    			which_indexes.push(rearranged[i*4+x]);
    			which_indexes.push(rearranged[i*4+y]);
    		};
    		which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    		which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    		if (which_indexes.indexOf(num) === -1) {
    			which_indexes.splice(Math.floor(Math.random()*which_indexes.length),1);
    			which_indexes.push(num);
    		};

    	};


    	var pre_answer = [];
    	for (var i=0; i<which_indexes.length; i++) {
    		pre_answer.push([pics[which_indexes[i]],langue[which_indexes[i]],nums[which_indexes[i]]]);
    	};

    	var pre_answer = jsPsych.randomization.repeat(pre_answer,1);

    	var message = '<div align="center"><table><tr><th colspan="'+numberPicsToMatch+'"><p>Сеуссе произнес следующую фразу: "'+stim+'". Что он имеет в виду? Нажмите соответствующую цифру (1-6) на клавиатуре.</p></th></tr><tr>';

	for (var i=0; i<6; i++) {
		message = message+'<th>'+pre_answer[i][0]+'<p>'+(i+1)+'</p></th>';
		if ((i>0) && ((i+1) % 3 === 0)) {message += '</tr><tr>';}
	};

    	message = message+'</tr></table></div>';
    	var answer = [message, num, get_inner_array(pre_answer,2), get_inner_array(pre_answer,1)];
    	return answer;
    };

    // creating all the stimuli
    function make_test1_stimuli() { //number is the index in the array

    	var lang = get_inner_array(language2,1);
    	var answer = [];
    	for (var i=0; i<lang.length; i++) {lang[i] = [i,lang[i]]};
    	for (var i=0; i<numberWordsInPerfTest; i++) {
    		var r = Math.floor(Math.random()*lang.length);
    		var temp = lang.splice(r,1)[0];
    		answer.push(make_test1_stimulus(temp[0],temp[1]));
    		setInterval(function(){var a = 0;},10); // otherwise the two random numbers are far too often next to each other
    	};
    	return answer;
    };

    // showing the stimuli
    var test1_stimuli = make_test1_stimuli();
    var test1_choices = [];
    var test1_counter = 0;
    var lottery_ticket_number = 1;
    for (i=1;i<=numberPicsToMatch;i++) {test1_choices.push(i.toString())};
    var test1_answers = '';
    var test1 = {
    	type: 'single-stim2',
    	stimuli: get_inner_array(test1_stimuli,0),
    	is_html: true,
    	correct_answer: test1_stimuli,
    	choices: test1_choices,
    	on_finish: function() {
    		test1_counter++;
        if ((test1_counter % 2) === 0) {
          if (test1_answers != '') {test1_answers += '\n'};
          test1_answers += ''+lang_line+','+(lang_prev+1)+','+jsPsych.data.getLastTrialData().correct_answer+','+jsPsych.data.getLastTrialData().given_answer+','+jsPsych.data.getLastTrialData().given_answer_pic+','+jsPsych.data.getLastTrialData().true_answer+','+jsPsych.data.getLastTrialData().true_answer_pic;
    		};
    		if (((test1_counter % 2) === 0) && (jsPsych.data.getLastTrialData().correct_answer)) {lottery_ticket_number++;};
      }
    };



    ///////////////
    // the actual testing - next generation languge
    ///////////////

    var new_lang = Array(16);
    var pre_final_pictures = get_inner_array(language2,3);
    for (var i=0; i<16; i++) {
    	pre_final_pictures[i]=[i,pre_final_pictures[i]];
    };
    pre_final_pictures = jsPsych.randomization.repeat(pre_final_pictures,1);
    var final_pictures = make_interim_questions(get_inner_array(pre_final_pictures,1));
    var test2_counter = 0;
    var test2 = {
    	type: 'survey-texta',
    	questions: final_pictures,
    	choices: [13],
    	on_finish: function() {
    		if (jsPsych.data.getLastTrialData().trial_type !== 'single-stim2') {
    			if ((test2_counter % 2) === 1) {
    				x = jsPsych.data.getLastTrialData().responses;
    				new_lang[pre_final_pictures[(test2_counter-1)/2][0]]=x;
    			};
    		};
    		test2_counter++;
    	},
    	on_trial_start: function() {
    		console.log('hello');
    	}
    };

    function check_input() {
    	for (i=0;i<16;i++) {
    		if (jQuery.trim($('#x'+(t[i]+1)).val()) === '') {return false;};
    	};
    	return true;
    };

    var test3_answers=[]

    function test3_continue() {
    	if (! check_input()) {
		alert('Сеуссе просит, чтобы вы описали все картинки!');
		return false;
	} else {
		var x = Array.apply(null, {length: 16}).map(Number.call, Number);
		for (i=0;i<16;i++) {
			x[i]=$('#x'+(i+1)).val();
		};
		test3_answers=x.join('//');
		return true;
	};
    	return true;
    };

    var test3 = {
    	type: 'html',
    	pages: [{url: "all_test.html", cont_btn: "response_button", check_fn: test3_continue}]
    };


    // changin the timer variables before the last test
    var counter1 = 30000;
    var counter2 = 15000;

    var change_timer = {
    	type: 'single-stim',
    	continue_after_response: false,
    	stimuli: '',
    	timing_response: 1,
    	on_finish: function() {
    		counter1 = 180000;
    		counter2 = 120000;
    	}
    };


    // initializing the experiment
    var structure = [intro1, intro2, consent_form, intro3, pre_pic, learning_interim_chunk, test1, test2];

	  var endtimerarray = [];
	  jsPsych.init({
      experiment_structure: structure,
      on_trial_start: function() {
	      	if (toIdleOrNotToIdle) {
            function inner_timer() {
              toWriteOrNotToWrite = false;
			        $.ajax({
                type: 'get',
					      async: false,
					      url: "status_change.php?line="+lang_line+"&change="+(lang_prev)
              });
              alert('Сеуссе обижается. Пожалуйста, ответьте как можно скорее.');
            };
            function second_timer() {
      				var d1 = new Date();
      				var time1 = d1.getTime();
      				var patience = '15 секунд';
      				if (counter2 !== 15000) { patience = '2 минут'; }
      				alert('Сеуссе скучает в ожидании вашего ответа. Пожалуйста, ответьте в течение '+patience+', или он обидится.');
      				var d2 = new Date();
      				var time2 = d2.getTime();
      				var x = counter2-(time2-time1);
      				if (x>0) {
      					endtimerarray[1] = setTimeout(function() {inner_timer();},x);
      				} else {
      					inner_timer();
      				};
            };
            endtimerarray[0] = setTimeout(function() {second_timer();}, counter1);
          };
        },
      on_trial_finish: function() {
	      		clearTimeout(endtimerarray[0]);
	      		clearTimeout(endtimerarray[1]);
      },
      on_finish: function() {
	      	notclosedBeforeEnd = true;
	        // saving the data and adding the metadata there
	        if (toWriteOrNotToWrite) {
		        var name_of_file = 'design_version'+design_version+'chain'+lang_line+'generation'+(lang_prev+1)+'type'+lang_type+'.csv';
		        meta_variables[2]++;
		        var metadata = meta_variables.join(",")+",";
		        $.ajax({
		          type:'post',
		          cache: false,
		          url: 'save_data.php',
		          data: {filename: name_of_file, filedata: jsPsych.data.dataAsCSV(), metadata: metadata, test: test3_answers}
		        });
		        // saving rough data - chain, generation, language type, learner type, number of correct answers, words not used in presentation
		        $.ajax({
		          type: 'post',
		          cache: false,
		          url: 'save_rough.php',
		          data: {data: lang_line+','+(lang_prev+1)+','+lang_type+','+lern_type+','+(lottery_ticket_number-1)+','+language4+','+participant_sex+','+participant_age}
		        });
		        // saving test1 data
		        $.ajax({
		          type: 'post',
		          cache: false,
		          url: 'save_test1.php',
		          data: {data: test1_answers}
		        });
		        // adding the new language to the existing file
		        $.ajax({
		          type: 'post',
		          cache: false,
		          url: 'add_lang.php',
		          data: {chain: lang_line, new_language: new_lang.join(",")}
		        });
		        // increasing the number of participants who have finished the experiment
		        $.ajax({
		          type: 'post',
		          cache: false,
		          url: 'send_email.php',
		          data: {}
		        });

		        // changing the status back to available;
		      	$.ajax({
		          type: 'get',
		          async: false,
		          url: "status_change.php?line="+lang_line+"&change="+(lang_prev+1)
		        });
	        };
	        // redirecting to outro screen
	        setInterval(function() {window.location.replace("outro.php?d="+lottery_ticket_number);}, 500);

      }
	    });
    </script>
</html>
