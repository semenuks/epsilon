<?php
$participant_number = intval(file_get_contents('data/participant_number.csv'))+1;
$part_n = $participant_number;
$max_number = 10; // this is the number of participants after which the email will be sent
echo $participant_number;
$to = 'asemenuk@ucsd.edu';
$to_sasha = 'aleksandrs.berdicevskis@uit.no';
$subject = $participant_number." = число участников, закончивших эксперимент epsilon";
$message = $subject;
if (($part_n % 10) == 0) {
	mail($to, $subject, $message);
	mail($to_sasha, $subject, $message);
}
file_put_contents('data/participant_number.csv', $participant_number);
?>
